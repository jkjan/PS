N = 0
TRUCKS = 0

PATTERN_INTERVAL = 240

RENT = 0
RETURN = 1
BIKES = 2

rental = [[0]]
deltas = [(-1, 0), (0, 1), (1, 0), (0, -1)]

