from collections import deque, defaultdict

import utils as ut
import parameters as pt
import api_utils as au


MAX_TIME = 720
scenario = 1

ut.select_scenario(scenario)
time = au.start(scenario)
history = au.get_all_history(scenario)
hot_places = ut.get_n_hot_places(history, pt.TRUCKS)
ut.init_rental()
truck_queue = defaultdict(lambda: deque())


while time < MAX_TIME:
    locations_info = au.locations()
    trucks_info = au.trucks()
    ut.renew_rental(locations_info)
    pattern = time // pt.PATTERN_INTERVAL
    visited = [False for _ in range(pt.N * pt.N)]
    commands = []

    for truck_info in trucks_info:
        truck_pos = truck_info["location_id"]
        pick_up = ut.find_nearest_spot(truck_pos, hot_places, pattern, pt.RETURN, visited)
        put = ut.find_nearest_spot(truck_pos, hot_places, pattern, pt.RENT, visited)

        queue = deque(ut.add_to_truck_command_queue(truck_pos, pick_up, put))

        if (time + (((len(truck_queue[truck_info["id"]]) + len(queue)) * 6) // 60)) // pt.PATTERN_INTERVAL == pattern:
            while len(queue) > 0:
                truck_queue[truck_info["id"]].append(queue.popleft())

            command = []

            for i in range(10):
                if len(truck_queue[truck_info["id"]]) > 0:
                    command.append(truck_queue[truck_info["id"]].popleft())
                else:
                    command.append(0)

        else:
            command = [0 for _ in range(10)]

        commands.append({"truck_id": truck_info["id"], "command": command})

    result = au.simulate(commands)
    print(result)
    time = result["time"]


s = au.score()
print(s)